#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char *argv[]) {
    printf(1, "hello from test prog\n");
    hello();
    exit(-1);
}
