#include "types.h"
#include "user.h"

void testWaitPid(void){
    int pid1, pid2=-1;
    int exit_status=0;


    pid1 = fork();
    if (pid1 == 0) {
        sleep(30);
    } else {
        pid2 = fork();
	if (pid2 != 0) {
		sleep(10);
	}
    }
    exit_status = 0;
    printf(1, "lets wait for the process with this pid: %d\n", pid2);
    if (waitpid(pid2, &exit_status, 0) > 0) {
         printf(1, "process exited!  pid is %d, exit_status is %d\n", pid2, exit_status);
    }
    else {
	printf(1, "waitpid issue: waited for a process with this pid %d\n", pid2);
    }
    return;
}
// test

int main(int argc, char *argv[])
{
    testWaitPid();
    exit(-1);
    // return 0;
}
