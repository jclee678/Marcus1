#include "types.h"
#include "user.h"

void testWaitExit(void){
    int pid1;
    int exit_status=0;


    pid1 = fork();
    if (pid1 == 0) {
        sleep(30);
    }
    else {
    	exit_status = 0;
    	printf(1, "before wait:  exit_status = %d\n", exit_status);
    	wait(&exit_status);
    	printf(1, "after wait:  exit_status = %d\n", exit_status);
    }
}
// test

int main(int argc, char *argv[])
{
    testWaitExit();
    exit(-1);
    // return 0;
}
